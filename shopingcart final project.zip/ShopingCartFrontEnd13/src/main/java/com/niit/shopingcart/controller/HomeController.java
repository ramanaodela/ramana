package com.niit.shopingcart.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class HomeController {	
	@RequestMapping("/")
	public ModelAndView homePage()
	{
		System.out.println("I am in homepage of controller");
		return new ModelAndView("index");
	}
	
	@RequestMapping("/home")
	public ModelAndView home()
	{
		System.out.println("I am in homepage controller");
		return new ModelAndView("home");
	}
	
	@RequestMapping("/home1")
	public ModelAndView home1()
	{
		System.out.println("I am in homepage controller");
		return new ModelAndView("home1");
	}
	
	@RequestMapping("/Home")
	public ModelAndView Home()
	{
		System.out.println("I am in Homepage controller");
		return new ModelAndView("Home");
	}
	
	@RequestMapping("/Contactus")
	public ModelAndView Contactus()
	{
		System.out.println("I am in Contactus controller");
		return new ModelAndView("Contactus");
	}
	
	@RequestMapping("/login")
	public ModelAndView login()
	{
		System.out.println("I am in login controller");
		return new ModelAndView("login");
	}
	

	
	
	@RequestMapping("/adminHome")
	public ModelAndView adminHome()
	{
		System.out.println("I am in adminHome controller");
		return new ModelAndView("adminHome");
	}
	
	@RequestMapping("/iphone")
	public ModelAndView iphone()
	{
		System.out.println("I am in iphone controller");
		return new ModelAndView("iphone");
	}
	
	@RequestMapping("/iphone6s")
	public ModelAndView iphone6s()
	{
		System.out.println("I am in iphone6s controller");
		return new ModelAndView("iphone6s");
	}
	
	@RequestMapping("/iphone7s")
	public ModelAndView iphone7s()
	{
		System.out.println("I am in iphone7s controller");
		return new ModelAndView("iphone7s");
	}
	
	@RequestMapping("/Payment")
	public ModelAndView Payment()
	{
		System.out.println("I am in Payment controller");
		return new ModelAndView("Payment");
	}
	
	@RequestMapping("/product")
	public ModelAndView product()
	{
		System.out.println("I am in product controller");
		return new ModelAndView("product");
	}
	
	@RequestMapping("/category")
	public ModelAndView category()
	{
		System.out.println("I am in category controller");
		return new ModelAndView("category");
	}
	
	@RequestMapping("/supplier")
	public ModelAndView supplier()
	{
		System.out.println("I am in supplier controller");
		return new ModelAndView("supplier");
	}
	
	@RequestMapping("/Thankyou")
	public ModelAndView Thankyou()
	{
		System.out.println("I am in Thankyou controller");
		return new ModelAndView("Thankyou");
	}
	
	@RequestMapping("/payment")
	public ModelAndView payment()
	{
		System.out.println("I am in payment controller");
		return new ModelAndView("payment");
	}
	
	@RequestMapping("/Productdetails")
	public ModelAndView Productdetails()
	{
		System.out.println("I am in Productdetails controller");
		return new ModelAndView("Productdetails");
	}
	
	@RequestMapping("/nocart")
	public ModelAndView nocart()
	{
		System.out.println("I am in nocart controller");
		return new ModelAndView("nocart");
	}
	
	@RequestMapping("/Thanku")
	public ModelAndView Thanku()
	{
		System.out.println("I am in Thanku controller");
		return new ModelAndView("Thanku");
	}
	
	@RequestMapping("/transaction")
	public ModelAndView transaction()
	{
		System.out.println("I am in transaction controller");
		return new ModelAndView("transaction");
	}
	

	@RequestMapping("/angular")
	public ModelAndView angular()
	{
		System.out.println("I am in angular controller");
		return new ModelAndView("angular");
	}
	

	@RequestMapping("/cart")
	public ModelAndView cart()
	{
		System.out.println("I am in cart controller");
		return new ModelAndView("cart");
	}
	
	@RequestMapping("/reg")
	public ModelAndView register()
	{
		System.out.println("I am in register controller");
		return new ModelAndView("register");
	}
	
}
