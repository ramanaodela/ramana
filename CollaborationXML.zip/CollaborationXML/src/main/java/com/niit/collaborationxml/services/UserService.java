package com.niit.collaborationxml.services;

import java.util.List;

import com.niit.collaborationxml.model.User;

public interface UserService
{
	public  void saveOrUpdate(User user);
	public User getUserById(int userid);
	public  List<User> list();
	public User getUserByname(String username);
	
	
}