package com.niit.collaborationxml.dao;

import java.util.List;

import com.niit.collaborationxml.model.User;

public interface UserDAO
{
	public void saveOrUpdate(User user);
	public User getUserById(int userid);
	public  List<User> list();
	public User getUserByname(String username);
	
	
}