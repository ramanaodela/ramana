package com.niit.collaborationxml.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Forum")
public class Forum {

	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(unique=true)
	  private int id;
	  @NotEmpty(message="title cannot be empty")
	  private  String title;
	  @NotEmpty(message="content should be there")
	  private String content;
	  
	  private Date creationdatetime;
	  @NotEmpty(message="category should be there")
	  private String category;
	  @NotEmpty(message="name should be there")
	  private String username;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getCreationdatetime() {
		return creationdatetime;
	}
	public void setCreationdatetime(Date creationdatetime) {
		this.creationdatetime = creationdatetime;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	  
}
