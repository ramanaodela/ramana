package com.niit.collaborationxml.controller;
import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.collaborationxml.model.User;
import com.niit.collaborationxml.services.UserService;


public class HomeController {
	
	@Autowired
	UserService userservice;

	ModelAndView mv;
	
	@RequestMapping("/")
	public ModelAndView LandPage()
	{
		mv = new ModelAndView("LandingPage");
		return mv;
	}
	
	@RequestMapping("/reg")
	public ModelAndView RegPage()
	{
		mv = new ModelAndView("register");
		return mv;
	}
	
	@RequestMapping("/login")
	public ModelAndView LoginP()
	{
		mv = new ModelAndView("LoginPage");
		return mv;
	}
	
	
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("user") User user , Model model,HttpServletRequest request, MultipartFile file) throws IOException
	{
		
		String filename = null;
	    byte[] bytes;
	    
	    		
	    		user.setActive(true);
	    		userservice.saveOrUpdate(user);
	    			System.out.println("Data Inserted");
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	    		MultipartFile image = user.getImage();
	            //Path path;
	            String path = request.getSession().getServletContext().getRealPath("/resources/images/"+user.getUserid()+".jpg");
	            System.out.println("Path="+path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image not saved");
	            	}
	            }
	    	
	     	    
	    return "LoginPage";
	
		
	}
	@ModelAttribute("user")
	public  User returnObject()
	{
		return new User();
	}
	

	  
	  @RequestMapping("/home")
	   public ModelAndView HomePageapp()
	  {
		  mv = new  ModelAndView("Home");
		  return mv;
	  }
	  
	



}