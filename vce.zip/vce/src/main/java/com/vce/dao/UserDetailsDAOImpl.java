package com.vce.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vce.dao.UserDetailsDAO;
import com.vce.model.UserDetails;

@Repository("userDetailsDAO")
public class UserDetailsDAOImpl implements UserDetailsDAO{

	public UserDetailsDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;


	public UserDetailsDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveOrUpdate(UserDetails userDetails) {
		System.out.println("***********saveOrUpdate called in UserDetailsDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		System.out.println(userDetails.getAddress());
		sessionFactory.getCurrentSession().saveOrUpdate(userDetails);
		t.commit();
	}
}
