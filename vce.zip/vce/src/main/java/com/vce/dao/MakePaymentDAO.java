package com.vce.dao;

import com.vce.model.makepayment;

public interface MakePaymentDAO {

//public List<MakePayment> list();

//public MakePayment get(String id);

public void saveOrUpdate(MakePaymentDAO makepaymentDAO);

//public void delete(int id);
}
