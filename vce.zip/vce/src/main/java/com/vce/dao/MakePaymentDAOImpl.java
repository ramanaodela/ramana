package com.vce.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vce.model.makepayment;


@Repository("makepaymentDAO")
public class MakePaymentDAOImpl implements MakePaymentDAO{
	
	public MakePaymentDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;


	public MakePaymentDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	/*@Transactional
	public List<MakePayment> list() {
		System.out.println("***********list called in MakePaymentDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<MakePayment> list = (List<MakePayment>) sessionFactory.getCurrentSession()
				.createCriteria(MakePayment.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
        t.commit();
		return list;
	}*/
	
	@Transactional
	public void saveOrUpdate(MakePaymentDAO billingAddress) {
		System.out.println("***********saveOrUpdate called in MakePaymentDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		sessionFactory.getCurrentSession().saveOrUpdate(billingAddress);
		t.commit();
	}

	public void saveOrUpdate(makepayment makePaymentDAO) {
		// TODO Auto-generated method stub
		
	}
	
	/*@Transactional
	public void delete(int id) {
	System.out.println("***********delete called in MakePaymentDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		MakePayment MakePaymentToDelete = new MakePayment();
		MakePaymentToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(MakePaymentToDelete);
		t.commit();
	}*/

	/*@Transactional
	public MakePayment get(String id) {
	System.out.println("***********get called in MakePaymentDAOImpl*********");
		String hql = "from MakePayment where id=" + id ;
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<MakePayment> list = (List<MakePayment>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		t.commit();
		return null;
	}*/

}
