package com.vce.dao;

import com.vce.model.UserDetails;

public interface UserDetailsDAO {
	
	public void saveOrUpdate(UserDetails userDetails);

}
