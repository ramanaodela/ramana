package com.vce.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "PAYMENT")
@Component
public class makepayment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int phonenumber;
	
	@NotEmpty(message = "card number cannot be empty")
	private String CardNumber;
	
	@NotEmpty(message = "expiry date cannot be empty")
	private String expiry;
	
	@NotEmpty(message = "cvv cannot be empty")
	private String cvv;
	
	@NotEmpty(message = "name on card cannot be empty")
	private String nameoncard  ;
     
	@NotEmpty(message = "amount cannot be empty")
	private Double amount  ;

	public int getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getCardNumber() {
		return CardNumber;
	}

	public void setCardNumber(String CardNumber) {
		this.CardNumber = CardNumber;
	}

	

	public String getExpiry() {
		return expiry;
	}

	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}


	public String getNameoncard() {
		return nameoncard;
	}

	public void setNameoncard(String nameoncard) {
		this.nameoncard = nameoncard;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	}