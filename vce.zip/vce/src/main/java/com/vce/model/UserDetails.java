package com.vce.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "USER_DETAILS")
public class UserDetails {
	@Id@GeneratedValue
	private int id;
	
	@NotNull(message="full name required")
	private String FullName;
	@NotNull(message="RollNumber required")
	private String RollNumber;
	@NotNull(message="DateOfBirth required")
	private String DateOfBirth;
	@NotNull(message="EmailId required")
	private String EmailId;
	@NotNull(message="PhoneNumber required")
	private String PhoneNumber;
	@NotNull(message="Address required")
	private String Address;
	private String paymentopt;
		
public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPaymentopt() {
		return paymentopt;
	}

	public void setPaymentopt(String paymentopt) {
		this.paymentopt = paymentopt;
	}

	public String getCVV() {
		return CVV;
	}

	public void setCVV(String cVV) {
		CVV = cVV;
	}

	
	private String ContactNumber;
	
	private String CardNumber;
	
	private String NameOnCard;
	
	private String Expirydate;
	
	private String CVV;
	

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getRollNumber() {
		return RollNumber;
	}

	public void setRollNumber(String rollNumber) {
		RollNumber = rollNumber;
	}

	public String getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}
	
	@Column
	private String Amount;

	
	public String getContactNumber() {
		return ContactNumber;
	}

	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}

	public String getCardNumber() {
		return CardNumber;
	}

	public void setCardNumber(String cardNumber) {
		CardNumber = cardNumber;
	}

	public String getNameOnCard() {
		return NameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		NameOnCard = nameOnCard;
	}

	public String getExpirydate() {
		return Expirydate;
	}

	public void setExpirydate(String expirydate) {
		Expirydate = expirydate;
	}

	public String getCvv() {
		return CVV;
	}

	public void setCvv(String cvv) {
		CVV = cvv;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	}