package com.vce.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.vce.dao.UserDetailsDAO;
import com.vce.model.UserDetails;

@Controller
public class HomeController {

	 @Autowired
		UserDetailsDAO userDetailsDAO;

	@RequestMapping("/")
	public ModelAndView homePage()
	{
		System.out.println("**********payment page called in HomeController***********");
		
		return new ModelAndView("payment","userd",new UserDetails());
	}
	
	@RequestMapping(value= "/details", method = RequestMethod.POST)
	public ModelAndView registerUser(@Valid@ModelAttribute("userd") UserDetails userDetails,BindingResult bindingResult) {
		System.out.println("************register called in UserDetailsController**********");
		if(bindingResult.hasErrors())
		{
			return new ModelAndView("payment");
		}
		System.out.println("payment opt:"+userDetails.getPaymentopt());
			userDetailsDAO.saveOrUpdate(userDetails);
		return new ModelAndView("redirect:/");
	  
	}
	/*@RequestMapping(value= "/details", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute UserDetails userDetails) {
		System.out.println("************register called in UserDetailsController**********");
		System.out.println("address:"+userDetails.getAddress());
		
		userDetailsDAO.saveOrUpdate(userDetails);
	   return new ModelAndView("redirect:/");
	 }*/
}
