package com.niit.collabchat.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collabchat.dao.BlogDao;
import com.niit.collabchat.model.Blog;

public class BlogTest1{
	@Autowired
static	BlogDao blogDAO;
	
	public static void main(String[] args)
		{
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		Blog cb=(Blog)context.getBean("blog");
		
		 System.out.println("after daos");
		
		cb.setId("101");
		cb.setTitle("blog1");
		cb.setDescription("about blog1");
		cb.setUser_Id("u_101");
		 blogDAO=(BlogDao) context.getBean("blogDao");
		System.out.println("entering values");
		blogDAO.saveorupdate(cb);
		System.out.println("after save or update");
		}
	
	}
