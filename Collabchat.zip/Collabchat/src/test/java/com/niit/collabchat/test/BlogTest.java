package com.niit.collabchat.test;

import static org.junit.Assert.*;

import org.hibernate.usertype.UserVersionType;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collabchat.dao.BlogDao;
import com.niit.collabchat.model.Blog;

public class BlogTest {


	private  Blog blog;
	
	@Autowired
	private BlogDao blogdao;
	
	@Autowired
	private AnnotationConfigApplicationContext context;


	
	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	
	
	@Before
	public void init()
	{
		blog = new Blog();
		System.out.println("am in test case");
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.collabchat");
		context.refresh();
		System.out.println("am in test case after refresh");
		//blog = (Blog)context.getBean("Blog");
		System.out.println("blog="+blog);
		blog.setId("1");
		blog.setTitle("baba");
		blog.setDescription("ram@123");
		blog.setUser_Id("ram@niit.com");
		blog.setDate_time("date");
		blog.setStatus("Success");
		blog.setReason("its good");
		
		
		
		blogdao =(BlogDao) context.getBean("blogdao");
		blogdao.saveorupdate(blog);
		
	}

	}
