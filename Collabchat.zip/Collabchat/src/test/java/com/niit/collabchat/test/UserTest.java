package com.niit.collabchat.test;

import static org.junit.Assert.*;

import org.hibernate.usertype.UserVersionType;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collabchat.dao.UserTableDao;
import com.niit.collabchat.model.UserTable;

public class UserTest {


	private  UserTable usertable;
	
	@Autowired
	private UserTableDao usertabledao;
	
	@Autowired
	private AnnotationConfigApplicationContext context;
	
	@Test
	public void test() {
		//fail("Not yet implemented");
	}
	
	
	@Before
	public void init()
	{
		usertable = new UserTable();
		System.out.println("am in test case");
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.collabchat");
		context.refresh();
		System.out.println("am in test case after refresh");
		//usertable = (UserTable)context.getBean("usertable");
		System.out.println("user table="+usertable);
		usertable.setId("1");
		usertable.setName("baba");
		usertable.setPassword("ram@123");
		usertable.setEmail("ram@niit.com");
		usertable.setMobile("123456");
		//usertable.setStatus("Success");
		
		usertable.setReason("rams 2nd");
		usertable.setAddress("rams 2nd");
		
		
		usertabledao =(UserTableDao) context.getBean("usertabledao");
		usertabledao.saveorupdate(usertable);
		
	}

	}
