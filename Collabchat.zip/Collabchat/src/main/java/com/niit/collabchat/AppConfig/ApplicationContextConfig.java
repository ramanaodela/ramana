package com.niit.collabchat.AppConfig;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.collabchat.dao.UserTableDao;
import com.niit.collabchat.dao.UserTableDaoImpl;
import com.niit.collabchat.model.UserTable;

import java.util.Properties;

import javax.sql.DataSource;

@Configuration
@ComponentScan("com.niit.collabchat")
@EnableTransactionManagement
public class ApplicationContextConfig 
{

	@Bean(name = "dataSource")
	public DataSource getOracleDataSource() {
		System.out.println("get DataSource() started...");
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@127.0.0.1:1521:XE");
		dataSource.setUsername("Ramana");
		dataSource.setPassword("123456");
		
	
		Properties connectionProperty = new Properties();
		connectionProperty.setProperty("hibernate.hbm2ddl.auto", "update");
		//connectionProperty.setProperty("hibernate.show_sql", "true");
		//connectionProperty.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
		//connectionProperty.setProperty("hibernate.format_sql", "true");
		dataSource.setConnectionProperties(connectionProperty);
		return dataSource;
	}
	
	
	
	private Properties getHibernateProperties()
	{
	System.out.println("getHibernateProperties() started...");

    	Properties properties = new Properties();
    	properties.put("hibernate.show_sql", "true");
    
    	
    	properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
    	return properties;
    }
	
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource)
	{
		System.out.println("getSessionFactory() started...");
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		System.out.println("session....."+sessionBuilder);
		sessionBuilder.addProperties(getHibernateProperties());	
		sessionBuilder.addAnnotatedClass(UserTable.class);
		return sessionBuilder.buildSessionFactory();
	}
	
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(
			SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
System.out.println("transaction=="+transactionManager);
		return transactionManager;
	}
	
	@Autowired
	@Bean(name="usertabledao")
	public UserTableDao getUserTableDao(SessionFactory sessionFactory)
	{
		return new UserTableDaoImpl(sessionFactory);
		
	}
	
}
