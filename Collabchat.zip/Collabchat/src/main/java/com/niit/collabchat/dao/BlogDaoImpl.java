package com.niit.collabchat.dao;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.collabchat.model.Blog;
import com.niit.collabchat.model.UserTable;

@Repository("blogdao")
public class BlogDaoImpl implements BlogDao {
	
	public BlogDaoImpl()
	{
		
	}

	
	@Autowired
	private SessionFactory sessionFactory;

	public BlogDaoImpl(SessionFactory sessionFactory) {

		try {
			this.sessionFactory = sessionFactory;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Transactional
	public void saveorupdate(Blog blog) {
		System.out.println("i am in blog dao");
		sessionFactory.getCurrentSession().saveOrUpdate(blog);
	}


}

	
//	public UserTable get(String id) {
//		String hql ="from UserTable where id="+"'"+id+"'";
//		Query query = sessionFactory.getCurrentSession().createQuery(hql);
//		
//		@SuppressWarnings("unchecked")
//		List<UserTable> list =(List<UserTable>)query.list();
//		if(list!=null && !list.isEmpty())
//		{
//			return list.get(0);
//		}
//		return null;
//	}
//
//	
//	@Transactional
//	public void delete(String id) {
//	UserTable user = new UserTable();
//	user.setId(id);
//	sessionFactory.getCurrentSession().delete(user);
//		
//	}
//
//	@Transactional
//	public List<UserTable> list() {
//		@SuppressWarnings("unchecked")
//		List<UserTable> list =(List<UserTable>)sessionFactory.getCurrentSession().createCriteria(UserTable.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
//		return list;
//	}
//
//	
//	public boolean isValidUser(String id, String password)
//	{
//		String hql = "from UserTable where id=' "+id+"' and "+"password=' "+password+"'";
//		Query query = sessionFactory.getCurrentSession().createQuery(hql);
//		
//		@SuppressWarnings("unchecked")
//		List<UserTable> list = (List<UserTable>)query.list();
//		
//		if(list!=null && !list.isEmpty())
//		{
//			return true;
//		}
//		else
//			return false;
//	}
//}
