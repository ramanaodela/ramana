package com.niit.collabchat.dao;

import java.util.List;
import com.niit.collabchat.model.Blog;

public interface  BlogDao
{
	public void saveorupdate(Blog blog);
	//public UserTable get(String id);
	//public void delete(String id);
	//public List<UserTable> list();
	//public boolean isValidUser(String id, String password);
}
