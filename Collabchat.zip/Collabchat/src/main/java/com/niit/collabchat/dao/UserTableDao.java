package com.niit.collabchat.dao;

import java.util.List;

import com.niit.collabchat.model.UserTable;

public interface UserTableDao 
{
	public void saveorupdate(UserTable usertable);
	//public UserTable get(String id);
	//public void delete(String id);
	//public List<UserTable> list();
	//public boolean isValidUser(String id, String password);
}
