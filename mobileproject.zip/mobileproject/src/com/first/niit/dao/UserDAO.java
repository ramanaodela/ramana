package com.first.niit.dao;

public class UserDAO 
{
public boolean isValidCredentials(String UserID,String password)
{
	if(UserID.equals("NIIT") && password.equals("12345"))
	{
		      return true;
		     
			}
	else
	{
		return false;
	}
	}
}

